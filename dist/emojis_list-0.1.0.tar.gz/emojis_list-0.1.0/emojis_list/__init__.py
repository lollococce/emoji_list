# import submodules you want to install

from .emoji_list import *

__docformat__ = "restructuredtext"


# module level doc-string
__doc__ = """
emoji_list - a package with all updated emoji list
=====================================================================

**emoji_list** is a Python package providing all updated emoji list
"""
